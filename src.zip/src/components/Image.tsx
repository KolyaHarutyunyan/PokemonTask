interface IImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  imgURL: string;
}

const Image: React.FC<IImageProps> = ({imgURL, ...props }) => {
    return (
        <>
            {
                imgURL.trim() !== "" ? (
                    <img
                        src={imgURL}
                        className="img"
                        {...props}
                    />
                ) : null
            }
        </>
    )
};

export default Image;