export default interface IPokemonCard {
    name: string;
    url: string;
    imgUrl: string;
}