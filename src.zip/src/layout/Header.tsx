import "./Header.css";

const Header = () => {
    return (
        <header className="header">
           <h1 className="title">Let's Discover Pokemons</h1>
        </header>
    );
};

export default Header;