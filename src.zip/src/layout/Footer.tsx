import "./Footer.css";

const Footer = () => {
    return (
        <footer className="footer">footer</footer>
    );
};

export default Footer;